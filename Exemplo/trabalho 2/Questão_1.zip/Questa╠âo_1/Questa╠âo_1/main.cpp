//---------------------------------------------------------------------------
#include <cstdlib>
#include <iostream>
//---------------------------------------------------------------------------
#include "Controladoras.h"
//---------------------------------------------------------------------------
using namespace std;

int main(int argc, char *argv[])
{
    
CntrIntNavegacao cntrIntNavegacao;
cntrIntNavegacao.executar();

    system("PAUSE");
    return EXIT_SUCCESS;
}
